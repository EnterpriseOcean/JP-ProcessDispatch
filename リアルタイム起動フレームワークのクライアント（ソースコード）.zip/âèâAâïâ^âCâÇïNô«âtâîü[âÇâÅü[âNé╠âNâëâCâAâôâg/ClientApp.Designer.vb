﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ClientApp
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.UserName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Password = New System.Windows.Forms.TextBox()
        Me.GetProcessInfo = New System.Windows.Forms.Button()
        Me.ProcessesList = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RunProcess = New System.Windows.Forms.Button()
        Me.ResultText = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Location = New System.Drawing.Point(25, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ユーザー名"
        '
        'UserName
        '
        Me.UserName.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.UserName.Location = New System.Drawing.Point(110, 22)
        Me.UserName.Name = "UserName"
        Me.UserName.Size = New System.Drawing.Size(215, 24)
        Me.UserName.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label2.Location = New System.Drawing.Point(26, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "パスワード"
        '
        'Password
        '
        Me.Password.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Password.Location = New System.Drawing.Point(110, 55)
        Me.Password.Name = "Password"
        Me.Password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Password.Size = New System.Drawing.Size(215, 24)
        Me.Password.TabIndex = 3
        '
        'GetProcessInfo
        '
        Me.GetProcessInfo.BackColor = System.Drawing.SystemColors.Highlight
        Me.GetProcessInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GetProcessInfo.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GetProcessInfo.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GetProcessInfo.Location = New System.Drawing.Point(28, 119)
        Me.GetProcessInfo.Name = "GetProcessInfo"
        Me.GetProcessInfo.Size = New System.Drawing.Size(158, 29)
        Me.GetProcessInfo.TabIndex = 4
        Me.GetProcessInfo.Text = "実行できるプロセスを取得"
        Me.GetProcessInfo.UseVisualStyleBackColor = False
        '
        'ProcessesList
        '
        Me.ProcessesList.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ProcessesList.FormattingEnabled = True
        Me.ProcessesList.Location = New System.Drawing.Point(110, 163)
        Me.ProcessesList.Name = "ProcessesList"
        Me.ProcessesList.Size = New System.Drawing.Size(215, 25)
        Me.ProcessesList.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label3.Location = New System.Drawing.Point(26, 166)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "プロセス名"
        '
        'RunProcess
        '
        Me.RunProcess.BackColor = System.Drawing.SystemColors.Highlight
        Me.RunProcess.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RunProcess.Font = New System.Drawing.Font("Meiryo UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.RunProcess.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.RunProcess.Location = New System.Drawing.Point(175, 204)
        Me.RunProcess.Name = "RunProcess"
        Me.RunProcess.Size = New System.Drawing.Size(150, 31)
        Me.RunProcess.TabIndex = 7
        Me.RunProcess.Text = "選択したプロセスを実行"
        Me.RunProcess.UseVisualStyleBackColor = False
        '
        'ResultText
        '
        Me.ResultText.AutoSize = True
        Me.ResultText.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ResultText.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ResultText.Location = New System.Drawing.Point(13, 255)
        Me.ResultText.Name = "ResultText"
        Me.ResultText.Size = New System.Drawing.Size(15, 15)
        Me.ResultText.TabIndex = 8
        Me.ResultText.Text = "　"
        '
        'ClientApp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.HotTrack
        Me.ClientSize = New System.Drawing.Size(353, 295)
        Me.Controls.Add(Me.ResultText)
        Me.Controls.Add(Me.RunProcess)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ProcessesList)
        Me.Controls.Add(Me.GetProcessInfo)
        Me.Controls.Add(Me.Password)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.UserName)
        Me.Controls.Add(Me.Label1)
        Me.Name = "ClientApp"
        Me.Text = "Blue Prism のプロセスを起動"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents UserName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Password As TextBox
    Friend WithEvents GetProcessInfo As Button
    Friend WithEvents ProcessesList As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents RunProcess As Button
    Friend WithEvents ResultText As Label
End Class

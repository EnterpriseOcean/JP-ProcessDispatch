﻿Public Class ClientApp
    Private Sub GetProcessInfo_Click(sender As Object, e As EventArgs) Handles GetProcessInfo.Click

        Dim client As New ReceptionJP.ReceptionJPPortTypeClient
        Dim processInfo As New ReceptionJP.GetProcessInfo
        Dim processInfoResponse As ReceptionJP.GetProcessInfoResponse
        Dim processes As ReceptionJP.GetProcessInfoOutProcessesRow()

        Try
            '認証情報をHTTPリクエストに設定
            client.ClientCredentials.UserName.UserName = UserName.Text
            client.ClientCredentials.UserName.Password = Password.Text

            'プロセスの情報を取得
            'Web API ProcessInfo を呼び出し
            processInfo.bpInstance = "auto"
            processInfoResponse = client.GetProcessInfo(processInfo)
            processes = processInfoResponse.Processes

            'コンボボックスに値を設定
            ProcessesList.Items.Clear()
            For i = 0 To processes.Length - 1
                ProcessesList.Items.Add(processes.ElementAt(i).name)
            Next i
        Catch ex As Exception
            If (ex.InnerException.ToString.StartsWith("System.Xml.XmlException")) Then
                Try
                    'ユーザー変更時の暫定対応中：リトライ
                    'プロセスの情報を取得
                    'Web API ProcessInfo を呼び出し
                    processInfo.bpInstance = "auto"
                    processInfoResponse = client.GetProcessInfo(processInfo)
                    processes = processInfoResponse.Processes

                    'コンボボックスに値を設定
                    ProcessesList.Items.Clear()
                    For i = 0 To processes.Length - 1
                        ProcessesList.Items.Add(processes.ElementAt(i).name)
                    Next i
                Catch ex2 As Exception
                    MsgBox(ex2.ToString)
                End Try
            Else
                MsgBox(ex.ToString)
            End If
        End Try

    End Sub

    Private Sub RunProcess_Click(sender As Object, e As EventArgs) Handles RunProcess.Click

        Dim client As New ReceptionJP.ReceptionJPPortTypeClient
        Dim result As Task(Of String)

        Try
            '認証情報をHTTPリクエストに設定
            client.ClientCredentials.UserName.UserName = UserName.Text
            client.ClientCredentials.UserName.Password = Password.Text

            'プロセスの実行をリクエスト
            'Web API ReceiveRunRequest を呼び出し
            result = client.ReceiveRunRequestAsync("auto", ProcessesList.Text, UserName.Text, Password.Text)
            result.Wait()

            ResultText.Text = result.Result

            'プロセス欄をクリア
            ProcessesList.Text = ""
        Catch ex As Exception
            Try
                'ユーザー変更時の暫定対応中：リトライ
                ResultText.Text = "エラーを検知しました。リトライしています…"
                System.Threading.Thread.Sleep(3000)
                result = client.ReceiveRunRequestAsync("auto", ProcessesList.Text, UserName.Text, Password.Text)
                result.Wait()

                ResultText.Text = result.Result

                'プロセス欄をクリア
                ProcessesList.Text = ""
            Catch ex2 As Exception
                MsgBox(ex2.ToString)
            End Try
        End Try
    End Sub
End Class

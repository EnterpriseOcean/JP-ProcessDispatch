﻿Public Class ClientApp
    Private Sub GetProcessInfo_Click(sender As Object, e As EventArgs) Handles GetProcessInfo.Click

        Dim client As New ReceptionJP.ReceptionJPPortTypeClient

        Try
            Dim processInfo As New ReceptionJP.GetProcessInfo
            Dim processInfoResponse As ReceptionJP.GetProcessInfoResponse
            Dim processes As ReceptionJP.GetProcessInfoOutProcessesRow()

            '認証情報をHTTPリクエストに設定
            client.ClientCredentials.UserName.UserName = UserName.Text
            client.ClientCredentials.UserName.Password = Password.Text

            'プロセスの情報を取得
            'Web API ProcessInfo を呼び出し
            processInfo.bpInstance = "auto"
            processInfoResponse = client.GetProcessInfo(processInfo)
            processes = processInfoResponse.Processes

            'コンボボックスに値を設定
            ProcessesList.Items.Clear()
            For i = 0 To processes.Length - 1
                ProcessesList.Items.Add(processes.ElementAt(i).name)
            Next i
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub RunProcess_Click(sender As Object, e As EventArgs) Handles RunProcess.Click

        Dim client As New ReceptionJP.ReceptionJPPortTypeClient

        Try
            '認証情報をHTTPリクエストに設定
            client.ClientCredentials.UserName.UserName = UserName.Text
            client.ClientCredentials.UserName.Password = Password.Text

            'プロセスの実行をリクエスト
            'Web API ReceiveRunRequest を呼び出し
            ResultText.Text = client.ReceiveRunRequest("auto", ProcessesList.Text, UserName.Text, Password.Text)

            'プロセス欄をクリア
            ProcessesList.Text = ""
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class
